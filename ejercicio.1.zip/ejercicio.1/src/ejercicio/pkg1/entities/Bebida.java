package ejercicio.pkg1.entities;

/**
 *
 * @author Werner
 */
public class Bebida extends Producto {

    private double litros;

    public Bebida(double litros, String nombre, int precio) {
        super(nombre, precio);
        this.litros = litros;
    }

    public double getLitros() {
        return litros;
    }
    @Override
    public String toString() {
        return "Nombre: "+super.getNombre()+" /// Litros: "+this.litros+" /// Precio: $"+super.getPrecio();
    }
}
