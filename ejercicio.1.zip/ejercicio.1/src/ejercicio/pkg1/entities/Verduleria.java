package ejercicio.pkg1.entities;

public class Verduleria extends Producto {

    private String UnidVenta;

    public Verduleria(String nombre, int precio, String Unidventa) {
        super(nombre, precio);
        this.UnidVenta = Unidventa;
    }

    public String getUnidVenta() {
        return UnidVenta;
    }
    @Override
    public String toString() {
        return "Nombre: "+super.getNombre()+" /// Precio: $"+super.getPrecio()+" /// Unidad de venta: "+this.UnidVenta;
    }
}
