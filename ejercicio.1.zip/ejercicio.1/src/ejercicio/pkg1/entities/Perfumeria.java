package ejercicio.pkg1.entities;

public class Perfumeria extends Producto {

    private String contenido;

    public Perfumeria(String nombre, int precio) {
        super(nombre, precio);
    }

    public Perfumeria( String contenido,String nombre,int precio) {
        super(nombre, precio);
        this.contenido = contenido;
    }

    public String getContenido() {
        return contenido;
    }
//Nombre: Coca-Cola Zero /// Litros: 1.5 /// Precio: $20
    @Override
    public String toString() {
        return "Nombre: "+super.getNombre()+" /// Contenido: "+this.contenido+" /// Precio: $"+super.getPrecio();
    }

}
