/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg1;

import ejercicio.pkg1.entities.Bebida;
import ejercicio.pkg1.entities.Perfumeria;
import ejercicio.pkg1.entities.Producto;
import ejercicio.pkg1.entities.Verduleria;
import java.util.ArrayList;
import java.util.Collections;

public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Producto> listaP = new ArrayList();
        cargar(listaP); //LLenamos la lista de elementos llamando al metodo cargar
        mostarLista(listaP); //Mostramos la lista llamando el metodo mostrarLista
        System.out.println("=============================");
        Collections.sort(listaP); // ordenamos la lista usando la interfaz comparable

        System.out.println("Producto más caro: " + listaP.get(listaP.size()-1).getNombre());
        System.out.println("Producto más barato: " + listaP.get(0).getNombre());

    }

    public static void cargar(ArrayList<Producto> listaP) {

        listaP.add(new Bebida(1.5, "Coca-Cola Zero", 20));
        listaP.add(new Bebida(1.5, "Coca-Cola", 18));
        listaP.add(new Perfumeria("500ml", "Shampoo Sedal", 19));
        listaP.add(new Verduleria("Frutillas", 64, "kilo"));

    }

    public static void mostarLista(ArrayList<Producto> listaP) {
        for (Producto producto : listaP) {
            System.out.println("" + producto.toString());

        }
    }

}
